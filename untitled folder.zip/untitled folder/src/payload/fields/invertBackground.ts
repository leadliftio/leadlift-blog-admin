import type { CheckboxField } from 'payload/types'

export const invertBackground: CheckboxField = {
  name: 'invertBackground',
  type: 'checkbox',
}
